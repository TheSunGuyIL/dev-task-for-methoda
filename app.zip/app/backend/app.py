from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///statuses.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Status(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    is_initial = db.Column(db.Boolean, default=False)

class Transition(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    from_status_id = db.Column(db.Integer, db.ForeignKey('status.id'), nullable=False)
    to_status_id = db.Column(db.Integer, db.ForeignKey('status.id'), nullable=False)

def create_tables():
    with app.app_context():
        db.create_all()

@app.route('/statuses', methods=['GET', 'POST', 'DELETE'])
def handle_statuses():
    if request.method == 'GET':
        statuses = Status.query.all()
        return jsonify([
            {"id": s.id, "name": s.name, "is_initial": s.is_initial}
            for s in statuses
        ])
    if request.method == 'POST':
        data = request.json
        new_status = Status(name=data['name'], is_initial=data.get('is_initial', False))
        db.session.add(new_status)
        db.session.commit()
        return jsonify({"message": "Status added"}), 201
    if request.method == 'DELETE':
        data = request.json
        status = Status.query.get(data['id'])
        if status:
            Transition.query.filter((Transition.from_status_id == status.id) | (Transition.to_status_id == status.id)).delete()
            db.session.delete(status)
            db.session.commit()
            return jsonify({"message": "Status and related transitions deleted"})
        return jsonify({"message": "Status not found"}), 404

@app.route('/transitions', methods=['GET', 'POST', 'DELETE'])
def handle_transitions():
    if request.method == 'GET':
        transitions = Transition.query.all()
        return jsonify([
            {"id": t.id, "name": t.name, "from_status_id": t.from_status_id, "to_status_id": t.to_status_id}
            for t in transitions
        ])
    if request.method == 'POST':
        data = request.json
        new_transition = Transition(name=data['name'], from_status_id=data['from_status_id'], to_status_id=data['to_status_id'])
        db.session.add(new_transition)
        db.session.commit()
        return jsonify({"message": "Transition added"}), 201
    if request.method == 'DELETE':
        data = request.json
        transition = Transition.query.get(data['id'])
        if transition:
            db.session.delete(transition)
            db.session.commit()
            return jsonify({"message": "Transition deleted"})
        return jsonify({"message": "Transition not found"}), 404

@app.route('/reset', methods=['POST'])
def reset_data():
    db.drop_all()
    db.create_all()
    return jsonify({"message": "Configuration reset"})

if __name__ == '__main__':
    create_tables()  # Call this to create tables if they don't exist.
    app.run(host='0.0.0.0', port=5000, debug=True)